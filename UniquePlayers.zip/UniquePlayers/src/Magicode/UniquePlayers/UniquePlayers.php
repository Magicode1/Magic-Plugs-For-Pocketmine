<?php

namespace Magicode\CustomAchievement;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerAchievementAwardedEvent;
class CustomAchievement extends PluginBase{
    
    public function enEnable(){
        $this->getLogger()->info("CustomAchievement loading.....");
        $this->saveDefaultConfig();
        $this->reloadConfig();
    }
        
    public function onDisable(){
        $this->getlogger()->info("CustomAchievement Disabling.....");
}
 public function getAcheivement(){
     
if $acheivement = 'Taking Inventory'


     
     
     
     
 }


}
